//
//  ViewController.swift
//  NSURLSessionwithrequestmathord
//
//  Created by MACOS on 11/26/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController,URLSessionDelegate {
 @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    @IBOutlet weak var txtempmob: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func btngetdata(_ sender: AnyObject) {
        
        //set emp id into first textfield
        let str = "http://localhost/crime/select.php?emp_id=\(txtempname.text!)"
        
        let url =  URL(string: str);
        
        let requet = URLRequest(url: url!);
        
        
        let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        
        let task = session.dataTask(with: requet) { (data, responce, err) in
            
            let resp = String(data: data!, encoding: String.Encoding.utf8)
            
            print(resp!);
        }
        
        task.resume();
    }
    
   
    @IBAction func insertdata(_ sender: AnyObject) {
    
     let str = "http://localhost/crime/insert.php?emp_name=\(txtempname.text!)&emp_add=\(txtempadd.text!)&emp_mob=\(txtempmob.text!)"
         let url =  URL(string: str);
        
        let requet = URLRequest(url: url!);
        
        
        let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        
        let task = session.dataTask(with: requet) { (data, responce, err) in
            
              let resp = String(data: data!, encoding: String.Encoding.utf8)
            
            print(resp);
        
            
            
        }
        
        task.resume();
        
    }

    
}

